namespace Magestore\InventorySuccess\Block\Adminhtml\Warehouse\Edit\Tab;
/**
 * Class Stock
 * @package Magestore\InventorySuccess\Block\Adminhtml\Warehouse\Edit\Tab
 */
class Stock extends \Magento\Backend\Block\Template
{
