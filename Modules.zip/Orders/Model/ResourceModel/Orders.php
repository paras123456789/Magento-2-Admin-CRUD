<?php
/**
* @author Paras Surya.
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Katalyst\Orders\Model\ResourceModel;

class Orders extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('katalyst_orders', 'katalyst_orders_id');
    }
}
