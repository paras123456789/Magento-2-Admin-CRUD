<?php
/**
* @author Paras Surya.
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Katalyst\design\Model\design\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class ParentCategory implements OptionSourceInterface
{

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {

        return [
          ['value' => '1', 'label' => __('cat 1')],
          ['value' => '2', 'label' => __('cat 2')],
          ['value' => '3', 'label' => __('cat 3')],
          ['value' => '4', 'label' => __('cat 4')]
        ];
    }
}
