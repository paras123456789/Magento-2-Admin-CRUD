<?php
/**
* @author Paras Surya.
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Katalyst\Design\Model\Design\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class Type implements OptionSourceInterface
{

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {

      return [
          ['value' => '1', 'label' => __('Wash/Fade')],
          ['value' => '2', 'label' => __('Riped/Details')],
          ['value' => '3', 'label' => __('Paints/Art')]
      ];
    }
}
