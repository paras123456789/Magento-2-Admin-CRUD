<?php
/**
* @author Paras Surya.
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Katalyst\Design\Model\ResourceModel\Design;

use \Katalyst\Design\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'katalyst_design_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Katalyst\Design\Model\Design', 'Katalyst\Design\Model\ResourceModel\Design');
        $this->_map['fields']['katalyst_design_id'] = 'main_table.katalyst_design_id';
    }
}
