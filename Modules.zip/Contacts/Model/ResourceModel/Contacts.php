<?php
/**
* @author Paras Surya.
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Katalyst\Contacts\Model\ResourceModel;

class Contacts extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{



    protected function _construct()
    {
        $this->_init('katalyst_contacts', 'katalyst_contacts_id');
    }
}
