<?php
/**
* @author Paras Surya.
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Katalyst\Contacts\Model\ResourceModel\Contacts;

use \Katalyst\Contacts\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'katalyst_contacts_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Katalyst\Contacts\Model\Contacts', 'Katalyst\Contacts\Model\ResourceModel\Contacts');
        $this->_map['fields']['katalyst_contacts_id'] = 'main_table.katalyst_contacts_id';
    }
}
