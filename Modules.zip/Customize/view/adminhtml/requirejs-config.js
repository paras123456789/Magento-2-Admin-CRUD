var config = {
    map: {
        '*': {
            customJs: 'Katalyst_Customize/js/custom'
        },
    },
    deps: ["jquery"]
};
