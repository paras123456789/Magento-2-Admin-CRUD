<?php

namespace Katalyst\Customize\Model;

class ProductOtherinfo extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init('Katalyst\Customize\Model\ResourceModel\ProductOtherinfo');
    }
}
