<?php

namespace Katalyst\Customize\Model;

class ProductFonts extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init('Katalyst\Customize\Model\ResourceModel\ProductFonts');
    }
}
