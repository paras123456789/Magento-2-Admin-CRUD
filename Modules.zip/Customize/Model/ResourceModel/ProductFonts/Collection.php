<?php


namespace Katalyst\Customize\Model\ResourceModel\ProductFonts;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    protected $_idFieldName = 'font_id';

    protected function _construct() {
        $this->_init('Katalyst\Customize\Model\ProductFonts', 'Katalyst\Customize\Model\ResourceModel\ProductFonts');
        $this->_map['fields']['font_id'] = 'main_table.font_id';
    }

}
