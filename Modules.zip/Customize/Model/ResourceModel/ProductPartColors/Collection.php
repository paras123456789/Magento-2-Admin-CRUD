<?php

namespace Katalyst\Customize\Model\ResourceModel\ProductPartColors;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{	
	protected $_idFieldName = 'color_id';

    protected function _construct()
    {
        $this->_init('Katalyst\Customize\Model\ProductPartColors', 'Katalyst\Customize\Model\ResourceModel\ProductPartColors');
        $this->_map['fields']['color_id'] = 'main_table.color_id';
    }
}
