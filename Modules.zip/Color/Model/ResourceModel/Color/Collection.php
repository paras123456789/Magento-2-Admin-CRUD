<?php
/**
* @author Paras Surya.
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Katalyst\Color\Model\ResourceModel\Color;

use \Katalyst\Color\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'katalyst_color_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Katalyst\Color\Model\Color', 'Katalyst\Color\Model\ResourceModel\Color');
        $this->_map['fields']['katalyst_color_id'] = 'main_table.katalyst_color_id';
    }
}
