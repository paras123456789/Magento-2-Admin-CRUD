var config = {
    map: {
        '*': {
              custom_script:'Katalyst_Color/js/custom_script'
             }
    }
};
