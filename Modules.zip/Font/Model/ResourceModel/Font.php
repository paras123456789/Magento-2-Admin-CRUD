<?php
/**
* @author Paras Surya.
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Katalyst\Font\Model\ResourceModel;

class Font extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{



    protected function _construct()
    {
        $this->_init('katalyst_font', 'katalyst_font_id');
    }
}
